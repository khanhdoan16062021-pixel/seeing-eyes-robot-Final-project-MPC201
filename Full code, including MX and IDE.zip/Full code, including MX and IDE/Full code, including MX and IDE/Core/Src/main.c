/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

volatile uint32_t dbg_echo = 0;
volatile uint32_t dbg_trig = 0;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/* ---------- Chan ---------- */
#define IN1_PORT   GPIOA
#define IN1_PIN    GPIO_PIN_4
#define IN2_PORT   GPIOA
#define IN2_PIN    GPIO_PIN_5
#define IN3_PORT   GPIOB
#define IN3_PIN    GPIO_PIN_0
#define IN4_PORT   GPIOB
#define IN4_PIN    GPIO_PIN_1

#define TRIG_PORT  GPIOB
#define TRIG_PIN   GPIO_PIN_6
#define ECHO_PORT  GPIOB
#define ECHO_PIN   GPIO_PIN_7

/* ---------- Thong so (HIEU CHINH THUC NGHIEM) ---------- */
#define SPEED_NORMAL        200
#define SPEED_SLOW          160
#define SPEED_TURN          180
#define SPEED_BACK          160

#define DIST_WARNING        60.0f
#define DIST_WARNING_EXIT   70.0f
#define DIST_STOP           35.0f

#define MEASURE_INTERVAL    30
#define ECHO_TIMEOUT_US     12000
#define TURN_90_MS          450
#define REVERSE_MS          500
#define SCAN_SETTLE_MS      350
#define SOUND_MIN_GAP       800
#define TIE_MARGIN          5.0f
#define MAX_BLOCKED         3

#define SERVO_US_MIN        500
#define SERVO_US_MAX        2500

/* ---------- Am thanh (so thu tu file tren the SD) ---------- */
#define SND_START           1
#define SND_OBSTACLE        2
#define SND_TURNING_LEFT    3
#define SND_TURNING_RIGHT   4
#define SND_PATH_CLEAR      6

typedef enum {
  ST_FORWARD, ST_OBSTACLE_SLOW, ST_STOPPED,
  ST_SCAN_LEFT, ST_SCAN_RIGHT, ST_DECIDE,
  ST_TURNING, ST_REVERSING
} RobotState;

static RobotState currentState = ST_FORWARD;
static uint32_t stateTimer = 0;
static uint32_t turnDuration = TURN_90_MS;

static float scanLeftResult = 0, scanRightResult = 0;
static bool  obstacleAlertSent = false;
static bool  preferLeft = false;
static int   blockedCount = 0;
static uint32_t lastSoundTime = 0;

static float    distBuf[3] = {999.0f, 999.0f, 999.0f};
static int      distIdx = 0;
static uint32_t lastMeasure = 0;

volatile float dbg_dist = 999.0f;   /* xem trong Live Expressions khi debug */

static float absf_(float x) { return x < 0 ? -x : x; }

/* ---------- Delay micro giay bang bo dem chu ky DWT ---------- */
static inline uint32_t cyc(void) { return DWT->CYCCNT; }

static void delay_us(uint32_t us)
{
  uint32_t ticks = us * (SystemCoreClock / 1000000U);
  uint32_t start = cyc();
  while ((cyc() - start) < ticks) { }
}

/* ---------- Motor (ENA/ENB = TIM1 CH1/CH2) ---------- */
static void setLeftMotor(int speed)
{
  if (speed >= 0) {
    HAL_GPIO_WritePin(IN1_PORT, IN1_PIN, GPIO_PIN_SET);
    HAL_GPIO_WritePin(IN2_PORT, IN2_PIN, GPIO_PIN_RESET);
  } else {
    HAL_GPIO_WritePin(IN1_PORT, IN1_PIN, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(IN2_PORT, IN2_PIN, GPIO_PIN_SET);
    speed = -speed;
  }
  if (speed > 255) speed = 255;
  __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, speed);
}

static void setRightMotor(int speed)
{
  if (speed >= 0) {
    HAL_GPIO_WritePin(IN3_PORT, IN3_PIN, GPIO_PIN_SET);
    HAL_GPIO_WritePin(IN4_PORT, IN4_PIN, GPIO_PIN_RESET);
  } else {
    HAL_GPIO_WritePin(IN3_PORT, IN3_PIN, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(IN4_PORT, IN4_PIN, GPIO_PIN_SET);
    speed = -speed;
  }
  if (speed > 255) speed = 255;
  __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, speed);
}

static void stopMotors(void)    { setLeftMotor(0);  setRightMotor(0); }
static void goForward(int s)    { setLeftMotor(s);  setRightMotor(s); }
static void reverseCmd(int s)   { setLeftMotor(-s); setRightMotor(-s); }
static void turnLeftCmd(int s)  { setLeftMotor(-s); setRightMotor(s); }
static void turnRightCmd(int s) { setLeftMotor(s);  setRightMotor(-s); }

/* ---------- Servo (TIM2 CH2 = PA1) ---------- */
static void servoWrite(int angle)
{
  if (angle < 0) angle = 0;
  if (angle > 180) angle = 180;
  uint32_t pulse = SERVO_US_MIN + ((uint32_t)angle * (SERVO_US_MAX - SERVO_US_MIN)) / 180;
  __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_2, pulse);
}

/* ---------- HC-SR04 ---------- */
static float readDistanceCM(void)
{
  const uint32_t perUs = SystemCoreClock / 1000000U;

  // 1. Phát xung Trigger 10us
  HAL_GPIO_WritePin(TRIG_PORT, TRIG_PIN, GPIO_PIN_RESET);
  delay_us(2);
  HAL_GPIO_WritePin(TRIG_PORT, TRIG_PIN, GPIO_PIN_SET);
  delay_us(10);
  HAL_GPIO_WritePin(TRIG_PORT, TRIG_PIN, GPIO_PIN_RESET);
  dbg_trig++;

  // 2. Chờ chân ECHO lên mức HIGH (Timeout 5ms)
  uint32_t t0 = cyc();

  while (HAL_GPIO_ReadPin(ECHO_PORT, ECHO_PIN) == GPIO_PIN_RESET) {
      dbg_echo = 0;

      if ((cyc() - t0) > (5000U * perUs)) {
          return 999.0f;
      }
  }

  dbg_echo = 1;

  // 3. Đo thời gian chân ECHO ở mức HIGH
  uint32_t start = cyc();
  uint32_t timeout_cycles = (uint32_t)ECHO_TIMEOUT_US * perUs;

  while (HAL_GPIO_ReadPin(ECHO_PORT, ECHO_PIN) == GPIO_PIN_SET) {

  if ((cyc() - start) > timeout_cycles) { dbg_echo = 2; return 999.0f; }

  }

  uint32_t end = cyc();

  // 4. Tính toán khoảng cách (tránh tràn số khi trừ)
  uint32_t dur = (end - start) / perUs;
  return ((float)dur * 0.0343f) / 2.0f;
}

static float median3(float a, float b, float c)
{
  if ((a >= b && a <= c) || (a <= b && a >= c)) return a;
  if ((b >= a && b <= c) || (b <= a && b >= c)) return b;
  return c;
}

static float readDistanceBlockingMedian(void)
{
  float a = readDistanceCM(); HAL_Delay(30);
  float b = readDistanceCM(); HAL_Delay(30);
  float c = readDistanceCM();
  return median3(a, b, c);
}

static float getDistanceNonBlocking(uint32_t now)
{
  if (now - lastMeasure >= MEASURE_INTERVAL) {
    lastMeasure = now;
    distBuf[distIdx] = readDistanceCM();
    distIdx = (distIdx + 1) % 3;
  }
  float m = median3(distBuf[0], distBuf[1], distBuf[2]);
  dbg_dist = m;
  return m;
}

static void primeDistanceBuffer(void)
{
  for (int i = 0; i < 3; i++) {
    distBuf[i] = readDistanceCM();
    HAL_Delay(30);
  }
  distIdx = 0;
  lastMeasure = HAL_GetTick();
}

/* ---------- DFPlayer Mini qua USART2 ---------- */
static void dfSend(uint8_t cmd, uint16_t param)
{
  uint8_t f[10];
  f[0] = 0x7E; f[1] = 0xFF; f[2] = 0x06; f[3] = cmd; f[4] = 0x00;
  f[5] = (uint8_t)(param >> 8);
  f[6] = (uint8_t)(param & 0xFF);
  uint16_t sum = 0xFF + 0x06 + cmd + 0x00 + f[5] + f[6];
  uint16_t chk = (uint16_t)(0 - sum);
  f[7] = (uint8_t)(chk >> 8);
  f[8] = (uint8_t)(chk & 0xFF);
  f[9] = 0xEF;
  HAL_UART_Transmit(&huart2, f, 10, 100);
}

static void playSound(uint16_t track, bool force)
{
  uint32_t now = HAL_GetTick();
  if (!force && (now - lastSoundTime < SOUND_MIN_GAP)) return;
  dfSend(0x03, track);
  lastSoundTime = now;
}

/* ---------- Chuyen trang thai tap trung ---------- */
static void setState(RobotState next)
{
  RobotState old = currentState;
  if (next == old) return;

  currentState = next;
  stateTimer = HAL_GetTick();

  switch (next) {
    case ST_FORWARD:
      if (old == ST_OBSTACLE_SLOW || old == ST_TURNING || old == ST_REVERSING) {
        playSound(SND_PATH_CLEAR, false);
      }
      obstacleAlertSent = false;
      servoWrite(90);
      break;

    case ST_OBSTACLE_SLOW:
      if (!obstacleAlertSent) {
        playSound(SND_OBSTACLE, false);
        obstacleAlertSent = true;
      }
      break;

    case ST_STOPPED:
      stopMotors();
      if (!obstacleAlertSent) {
        playSound(SND_OBSTACLE, false);
        obstacleAlertSent = true;
      }
      break;

    case ST_SCAN_LEFT:
      stopMotors();
      servoWrite(150);
      break;

    case ST_SCAN_RIGHT:
      servoWrite(30);
      break;

    case ST_DECIDE:
      servoWrite(90);
      break;

    default:
      break;
  }
}

/* ---------- Khoi tao robot ---------- */
static void robot_hw_start(void)
{
  /* bat bo dem chu ky DWT (dung cho delay_us va do echo) */
  CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
  DWT->CYCCNT = 0;
  DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;

  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);   /* ENA  PA8 */
  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_2);   /* ENB  PA9 */
  HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_2);   /* servo PA1 */

  stopMotors();
  servoWrite(90);
}

static void robot_init(void)
{
  robot_hw_start();

  HAL_Delay(1000);              /* cho DFPlayer khoi dong */
  dfSend(0x0C, 0);              /* reset */
  HAL_Delay(1500);
  dfSend(0x06, 22);             /* am luong 0..30 */
  HAL_Delay(200);
  playSound(SND_START, true);

  HAL_Delay(300);
  primeDistanceBuffer();

  currentState = ST_FORWARD;
  stateTimer = HAL_GetTick();
}

/* ---------- Vong lap chinh cua robot ---------- */
static void robot_loop(void)
{
  uint32_t now = HAL_GetTick();
  uint32_t elapsed = now - stateTimer;
  switch (currentState) {

    case ST_FORWARD: {
      float dist = getDistanceNonBlocking(now);
      if (dist <= DIST_STOP)            setState(ST_STOPPED);
      else if (dist <= DIST_WARNING)    setState(ST_OBSTACLE_SLOW);
      else                              goForward(SPEED_NORMAL);
      break;
    }

    case ST_OBSTACLE_SLOW: {
      float dist = getDistanceNonBlocking(now);
      if (dist <= DIST_STOP)                 setState(ST_STOPPED);
      else if (dist > DIST_WARNING_EXIT)     setState(ST_FORWARD);
      else                                   goForward(SPEED_SLOW);
      break;
    }

    case ST_STOPPED:
      stopMotors();
      if (elapsed > 200) setState(ST_SCAN_LEFT);
      break;

    case ST_SCAN_LEFT:
      if (elapsed > SCAN_SETTLE_MS) {
        scanLeftResult = readDistanceBlockingMedian();
        setState(ST_SCAN_RIGHT);
      }
      break;

    case ST_SCAN_RIGHT:
      if (elapsed > SCAN_SETTLE_MS) {
        scanRightResult = readDistanceBlockingMedian();
        setState(ST_DECIDE);
      }
      break;

    case ST_DECIDE: {
      bool leftOK  = scanLeftResult  > DIST_STOP;
      bool rightOK = scanRightResult > DIST_STOP;

      if (!leftOK && !rightOK) {
        blockedCount++;
        if (blockedCount >= MAX_BLOCKED) {
          blockedCount = 0;
          turnDuration = TURN_90_MS * 2;            /* quay 180 do */
          playSound(SND_TURNING_RIGHT, false);
          turnRightCmd(SPEED_TURN);
          setState(ST_TURNING);
        } else {
          reverseCmd(SPEED_BACK);
          setState(ST_REVERSING);
        }
        break;
      }

      bool goLeft;
      if (leftOK && rightOK) {
        if (absf_(scanLeftResult - scanRightResult) < TIE_MARGIN) {
          goLeft = preferLeft;
          preferLeft = !preferLeft;
        } else {
          goLeft = scanLeftResult > scanRightResult;
        }
      } else {
        goLeft = leftOK;
      }

      blockedCount = 0;
      turnDuration = TURN_90_MS;

      if (goLeft) { playSound(SND_TURNING_LEFT, false);  turnLeftCmd(SPEED_TURN); }
      else        { playSound(SND_TURNING_RIGHT, false); turnRightCmd(SPEED_TURN); }
      setState(ST_TURNING);
      break;
    }

    case ST_TURNING:
      if (elapsed > turnDuration) {
        stopMotors();
        HAL_Delay(100);
        primeDistanceBuffer();
        setState(ST_FORWARD);
      }
      break;

    case ST_REVERSING:
      if (elapsed > REVERSE_MS) {
        stopMotors();
        setState(ST_STOPPED);
      }
      break;

    default:
      break;
  }
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM1_Init();
  MX_USART2_UART_Init();
  MX_TIM2_Init();
  /* USER CODE BEGIN 2 */
  robot_init();
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

	  robot_loop();


  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
